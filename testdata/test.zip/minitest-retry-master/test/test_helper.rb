$LOAD_PATH.unshift File.expand_path('../../lib', __FILE__)
require 'pry'
require 'minitest/retry'
require 'minitest/autorun'
