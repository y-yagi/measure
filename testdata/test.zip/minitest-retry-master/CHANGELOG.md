## 0.1.9

* Add on_consistent_failure callback #20 [staugaard]

## 0.1.8

* Add retry callback #17 [julien-meichelbeck]
* Pass test class and test name to failure callback #15, #16 [julien-meichelbeck]

## 0.1.7

* Run a callback on each test failure #15 [julien-meichelbeck]

## 0.1.6

* Add exceptions_to_retry option #13 [panjan]

## 0.1.5

* Improve message information when an unexpected error occurs #9 [abarre]

## 0.1.4

* Fix typo in verbose output #6 [semanticart]

## 0.1.3

* modify so as not to retry it a had gone to retry the skip test.
