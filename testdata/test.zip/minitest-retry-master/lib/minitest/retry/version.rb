module Minitest
  module Retry
    VERSION = "0.1.9"
  end
end
